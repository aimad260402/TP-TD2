public class Main {
    public static void main(String[] args) {
        Point a =new Point(0,0);
         Point b= new Point(5,9);
        a.setX(2);a.setY(7);b.setX(2);b.setY(5);
       System.out.println(a.ToString());
        //p.setX(3);
        //p.setY(4);
        //point p =new point();
       // point q = p;
        Object p=new Point();
        Object q=new Point();
        String s1="hello";
        String s3="hello";
        String s2=new String("hello");
        System.out.println(s1==s2);
        System.out.println(s1==s3);
        System.out.println(a.distance(b));
        System.out.println(p.equals(q));
        Moteur M1 = new Moteur("C12", 6000);
        Voiture V1 = new Voiture("99", "BMW", 10.0, true, M1);

    }

}