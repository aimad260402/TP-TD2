public class Voiture {
    private String modele;
    private String marque ;
    private Double vetesse;
    private boolean estdemarre;
    public Moteur moteur;

    public Voiture(String modele, String marque, Double vetesse, boolean estdemarre, Moteur moteur) {
        this.modele = modele;
        this.marque = marque;
        this.vetesse = vetesse;
        this.estdemarre = estdemarre;
        this.moteur = moteur;
    }
    public double deQuellePuissance() {
        return moteur.getPuissance();
    }

    public void changerLeMoteur(Moteur nvMoteur) {
        moteur = nvMoteur;
    }

    public int dequellepuissance(){
        return moteur.getPuissance();
    }
    public void démarre(){
        this.estdemarre=true;

    }
    public void Accelere(float x){
        this.vetesse += x;

    }

    public String SetModele() {
        return modele;
    }
    public void SetModele(String modele) {
        this.modele = modele;
    }
    public String SetMarque() {
        return marque;
    }
    public void setMarque(String marque) {
        this.marque = marque;
    }
    public Double SetVetesse() {
        return vetesse;
    }
    public void SetVetesse(Double vetesse) {
        this.vetesse = vetesse;
    }

    public void SetEstdemarre(boolean estdemarre) {
        this.estdemarre = estdemarre;
    }

    public boolean isEstdémarre() {
        return estdemarre;
    }
}

