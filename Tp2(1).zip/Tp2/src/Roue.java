public class Roue {
    private int largeur;
    private int  DiametreJante;
    public int getLargeur() {
        return largeur;
    }
    public void SetLargeur(int largeur) {
        this.largeur = largeur;
    }
    public int GetDiametreJante() {
        return this.DiametreJante;
    }
    public void setDiamétreJanté(int diametreJante) {
        this.DiametreJante = diametreJante;
    }
}
