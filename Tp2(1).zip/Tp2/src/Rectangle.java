public class Rectangle {
    private Point hg;
    private Point bd;
    public Rectangle(){ };

    public Rectangle(Point h , Point d){
        this.hg = h ;
        this.bd = d;
    }
    public  void afficher(){
        System.out.println("haut a gauche :"+this.hg.toString());
        System.out.println("bas a droit   :"+this.bd.toString());
    }
    public double surface(){
        Point bg = new Point(this.hg.getX(), this.bd.getY());

        return (bg.distance(hg) * bg.distance(bd));
    }
    public void zoom(int deltax , int deltay){
        this.bd.setX(deltax);
        this.bd.setY(deltay);
    }


}
